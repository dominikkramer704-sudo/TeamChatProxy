package durchlasten;

import net.md_5.bungee.api.plugin.*;
import net.md_5.bungee.api.event.*;
import net.md_5.bungee.api.connection.*;
import net.md_5.bungee.api.*;
import net.md_5.bungee.api.chat.*;
import java.util.*;
import net.md_5.bungee.event.*;

public class durchlastenbungee extends Plugin implements Listener
{
    public void onEnable() {
        this.getProxy().getPluginManager().registerListener((Plugin)this, (Listener)this);
        this.getLogger().info("Durchlasten Teamchat aktiviert!");
    }
    
    @EventHandler
    public void onChat(final ChatEvent event) {
        if (event.isCommand() || !(event.getSender() instanceof ProxiedPlayer)) {
            return;
        }
        final ProxiedPlayer player = (ProxiedPlayer)event.getSender();
        final String message = event.getMessage();
        if (!message.startsWith("@team ")) {
            return;
        }
        if (!player.hasPermission("durchlasten.teamchat")) {
            player.sendMessage((BaseComponent)new TextComponent(ChatColor.translateAlternateColorCodes('&', "&6&lDURCHLASTEN &8� &7Diesen Befehl gibt es nicht. Benutze &e/help&7!")));
            event.setCancelled(true);
            return;
        }
        final String teamMessage = message.substring(6);
        String serverPrefix = "";
        if (player.getServer() != null && player.getServer().getInfo() != null) {
            serverPrefix = "&7[" + player.getServer().getInfo().getName() + "] ";
        }
        final String finalMessage = ChatColor.translateAlternateColorCodes('&', "&6&lTEAMCHAT " + serverPrefix + player.getName() + " &8� &6" + teamMessage);
        for (final ProxiedPlayer p : this.getProxy().getPlayers()) {
            if (p.hasPermission("durchlasten.teamchat")) {
                p.sendMessage((BaseComponent)new TextComponent(finalMessage));
            }
        }
        event.setCancelled(true);
    }
}
